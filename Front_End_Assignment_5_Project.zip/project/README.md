# Web Dev Guide - Assignment 5 test package

Team: EMEMDANCE, SE-2514.
Members: Nurdaulet Zhanybek, Yelnur Yessenali, Pribylyov Yegor.

## Run
Extract the ZIP, open project/index.html, and use the navigation links. No installation or build is needed. Bootstrap 5.3.8 loads from its existing CDN, so internet access is required for Bootstrap styling and the collapsible navigation.

## Assignment 5
- HTML Basics: lesson filter and two-step HTML practice plan.
- HTML Advanced: Read More, lesson rating, moving HTML box and sound.
- CSS Basics: lesson filter and two-step CSS practice plan.
- CSS Layout: Read More, lesson rating, moving CSS box and sound.
- JS Basics: lesson filter and two-step study plan.
- JS DOM: Read More, lesson rating, moving DOM box and sound.
- All six pages: arrow-key navigation, existing page scripts and shared css/js-assignment.css.

Assignment 5 follows Assignment 4 in js/html-assignment.js, js/css-assignment.js, js/js-basics.js and js/js-dom.js. Each page loads its original script. The code demonstrates objects and methods, arrays, loops, filter callbacks, switch, event listeners, content and attribute updates, audio playback and CSS transitions. Forms are browser-only exercises and do not send or store data.

## Version status
This is a local integrated test version based on commit 6fb7052. The temporary HTML/CSS additions and the script reorganization have not been committed or pushed. They can be replaced by the team members' implementations later.

Existing published site: https://e1noor.github.io/front_end/
Repository: https://github.com/e1noor/front_end
The published site currently contains the committed JS part. The complete version documented here is the project folder in this archive.
